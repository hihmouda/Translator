//
//  AppDefaults.swift
//  Translator
//
//  Created by hadeel on 12/8/18.
//  Copyright © 2018 Hadeel. All rights reserved.
//

import Foundation

struct AppDefaults {
    
    static let apiKey:String                 = "trnsl.1.1.20181208T204852Z.97f444c6a2d3ff63.1d38ab7599bb8cb5f89799c65ec4c53f798e8b7b"

}
