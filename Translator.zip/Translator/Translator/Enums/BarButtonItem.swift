//
//  BarButtonItem.swift
//  Hypanion
//
//  Created by hadeel on 11/3/18.
//  Copyright © 2018 Hadeel. All rights reserved.
//

import Foundation

enum BarButtonItem {
    
    case leftBarButton
    case rightBarButton
    
}
